const env = import.meta.env;
export const BACKEND_URL = env.VITE_REACT_BACKENDURL;
export const SOCKET_URL = env.VITE_REACT_SOCKETURL;
