export interface otpVerificationType {
  id: string;
  email: string;
  otp: string;
}
