export const badWords = ["bbww", "stupid", "idiot"];
