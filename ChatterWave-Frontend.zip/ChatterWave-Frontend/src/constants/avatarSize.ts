export enum sizeList {
  default,
  small,
  large,
  medium,
}
