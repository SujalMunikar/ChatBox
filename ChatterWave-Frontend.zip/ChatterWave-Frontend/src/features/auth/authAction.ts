import { createAsyncThunk } from "@reduxjs/toolkit";
import api from "../../config/axiosConfig";
import toast from "react-hot-toast";

interface LoginDetailsType {
  email: string;
  password: string;
}
interface VerificationDetailsType {
  email: string;
  id: string;
  otp: string;
}

interface RegisterDetailsType {
  name: string;
  email: string;
  password: string;
}

export const login = createAsyncThunk(
  "login",
  async (data: LoginDetailsType) => {
    const { email, password } = data;
    try {
      const res = await api.post("http://localhost:8000/auth/login", {
        email,
        password,
      });
      if (res.status === 200) {
        if (!res?.data?.data?.verified) {
          toast(
            "OTP has been sent to your email.\n\n Please enter the OTP or click the link in the email to proceed."
          );
        } else {
          toast.success("Logged in");
        }
        return res?.data;
      } else {
        toast.error("Invalid Credentials");
      }
    } catch (error: any) {
      console.log("Login Failed", error);
      toast.error(error?.response?.data?.message);
    }
  }
);

export const register = createAsyncThunk(
  "register",
  async (data: RegisterDetailsType) => {
    const { name, email, password } = data;
    try {
      const res = await api.post("http://localhost:8000/auth/register", {
        email,
        password,
        name,
      });
      console.log(res);
      if (res.status === 201) {
        toast.success("Account Created");
        // if (!res?.data?.data?.verified) {
        //   toast("Account Created");
        // }
        console.log(res?.data);
        return res?.data;
      }
    } catch (error: unknown) {
      console.log(error);
      toast.error(error?.response?.data?.message);
    }
  }
);

export const logout = createAsyncThunk("logout", async () => {
  try {
    const res = await api.get("http://localhost:8000/auth/logout");
    return res?.data;
  } catch (error: unknown) {
    console.log(error);
  }
});

export const getme = createAsyncThunk("getme", async () => {
  try {
    const res = await api.get("http://localhost:8000/auth/getme");
    if (res.status === 200) {
      return res?.data;
    }
  } catch (error: unknown) {
    console.log(error);
  }
});

export const verifyEmail = createAsyncThunk(
  "verifyEmail",
  async (data: VerificationDetailsType) => {
    const { email, id, otp } = data;
    try {
      const res = await api.get(
        `http://localhost:8000/auth/verify-email?id=${id}&email=${email}&otp=${otp}`
      );
      return res?.data;
    } catch (error: unknown) {
      console.log(error);
    }
  }
);

export const updatePassword = createAsyncThunk(
  "updatePassword",
  async (data: any) => {
    try {
      const res = await api.post("http://localhost:8000/auth/reset-password", {
        oldPassword: data.oldPassword,
        newPassword: data.newPassword,
      });
      if (res.status === 200) {
        if (data?.onSuccess) {
          data.onSuccess();
        }
        toast.success("Password updated successfully");
        return res?.data;
      } else {
        toast.error("Password update failed");
      }
    } catch (error: unknown) {
      console.log(error);
      toast.error("Password update failed");
    }
  }
);
